create database gym 
create table Customers (
Customer_name	Varchar(50)	Not Null,
CustomerId	Int	identity(10000,1) not null primary key,
Cust_join_date	Date	Not Null,
Cust_package_name	Varchar(50)	Not Null,
Cust_renewal_date	Date	Not Null,
Cust_height	Varchar(50)	Not Null,
Cust_weight	Varchar(50)	Not Null,
Cust_pay_amount	Int	Not null ,
Exc_type	Varchar(50)	Not Null,
TrainerID	Int	 not null FOREIGN KEY REFERENCES Trainer(TrainerID),
MemberID	Int  not null FOREIGN KEY REFERENCES Membership(MemberID),
);
create table  Manager  (
ManagerID	Int identity(1000,1) not null primary key , 
ManagerName	Varchar(50)	Not Null,
ManLastName	Varchar(50)	Not Null,
AppointDate	date	Not Null,
Service	Int	Not Null,
Salary	Numeric(5,2)	Not Null,
Man_work_hour	int	Not Null
CustomerId	Int	not null FOREIGN KEY REFERENCES Customers(CustomerId),
);

 create table Staff(
 StaffId	Int	identity(5000,1) not null primary key,
StaffName	Int	Not Null,
Staff_work_hour	Int	Not Null,
Staff_join_date	Date	Not Null,
Staff_leave_date	Date	Not Null,
Staff_salary	Numeric(5,2)	Not Null,
Staff_service	int	Not Null,
ManagerID	Int	not null FOREIGN KEY REFERENCES Manager(ManagerID),
 );

   create table Trainer( 
   
   Trainer_name	Varchar(50)	Not Null,
TrainerID	Int	identity(2000,1) not null primary key, 
CustomerID	Int	not null FOREIGN KEY REFERENCES Customers(CustomerID	),
Trainer_work_hour	Int	Not Null,
Trainer_rating	Int	Null,
Trainer_salary	Numeric(5,2)	Not Null,
Trainer_join_date	Date	Not Null,
Trainer_leave_date	Date	Not Null,

   
   );

  create table  Equipments(

Equip_name	Varchar(50)	Not Null,
Equip_buy_date	Date	Not Null,
Equip_maintenance_date	Date	Not Null,
Equip_payment_ID	Int	Not Null,
Equip_type	Varchar(50)	Not Null,
Equip_cost	Numeric(5,2)	Not Null

);

create table Membership(

MemberID	Int	identity(9000,1) not null primary key,
Date_created	Date	Not Null,
Expiry_dates	Date	Not Null,
TrainerID	Int	not null FOREIGN KEY REFERENCES  Trainer(TrainerID),
CustomerID	Int not null FOREIGN KEY REFERENCES Customers(CustomerID)
);

 create Table  Package (
Pack_name	Varchar(50)	Not Null,
Customer_name	Varchar(50)	Not Null,
Pack_duration	Date	Not Null,
Pack_price	Int	Not Null,
CustomerID	Int not null FOREIGN KEY REFERENCES Customers(CustomerID)

);








