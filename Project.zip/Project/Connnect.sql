Alter login sa with password = '123456'
Alter login sa enable
