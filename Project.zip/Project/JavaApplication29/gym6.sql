create database gym6

create table  Manager(
ManagerID	Int identity(1,1) not null primary key, 
ManagerName	Varchar(50)	Not Null,
AppointDate	date Not Null,
Salary	Numeric(8,2) Not Null,
Man_work_hour	int	Not Null,
);
insert into Manager(ManagerName, AppointDate, Salary, Man_work_hour)
values  ('Saad','2019-01-01', 30000.00, 8),
		('Aasim','2019-05-01', 27000.00, 7),
		('Zain','2019-07-01', 25000.00, 7);

create table Staff(
StaffId	Int	identity(500,1) not null primary key,
StaffName Varchar(50) Not Null,
Staff_work_hour	Int	Not Null,
Staff_join_date	Date	Not Null,
Staff_leave_date	Date	Not Null,
Staff_work_as varchar(50) not null,
Staff_salary	Numeric(7,2)	Not Null,
ManagerID	Int	not null FOREIGN KEY REFERENCES Manager(ManagerID),
 );
insert into Staff(StaffName,Staff_work_hour, Staff_join_date, Staff_leave_date, Staff_work_as, Staff_salary, ManagerID)
values  ('Manik', 8, '2019-01-01', '2024-01-01','Service technicians', 10000.00, 1),
		('Faisal', 9, '2019-08-01', '2023-08-01','Massage therapist', 11000.00, 2),
		('Saikat', 8, '2020-12-01', '2025-12-01','Group fitness instructor', 10000.00, 1),
		('Mahabub', 8, '2019-01-01', '2024-01-01','Maintainance personnel', 10000.00, 1),
		('Pial', 8, '2020-03-01', '2023-03-01','Nuitrition consultant', 9000.00, 3),
		('Mishal', 10, '2019-12-01', '2023-12-01','Fitness consultant', 9000.00, 3),
		('Arslaan', 9, '2019-07-01', '2025-07-01','Front desk associate', 9500.00, 2),
		('Faisal', 9, '2019-08-01', '2024-08-01','Facility supervisor', 12500.00, 2);

create table Trainer( 
Trainer_name Varchar(50)	Not Null,
TrainerID	Int	identity(3000,1) not null primary key, 
Trainer_work_hour	Int	Not Null,
Trainer_rating	varchar(10)	Null,
Trainer_salary	int	Not Null,
Trainer_join_date	Date	Not Null,
);

insert into Trainer(Trainer_name, Trainer_join_date, Trainer_rating, Trainer_salary, Trainer_work_hour)
values	('Labeeb', '2019-05-01', '3 star', 10000, 9),
		('Shamim', '2019-03-01', '2 star', 9500, 9),
		('Fahim', '2019-02-01', '3 star', 10000, 9),
		('Usman', '2019-07-01', '5 star', 11000, 10),
		('Amir', '2019-01-01', '4 star', 10000, 9);

create table Customers (
Customer_name	Varchar(50)	Not Null,
CustomerId	Int	identity(1000,1) not null primary key,
Cust_join_date	Date	Not Null,
Cust_package_name	Varchar(50)	Not Null,
Cust_height	Varchar(50)	Not Null,
Cust_weight	Varchar(50)	Not Null,
Cust_pay_amount	Numeric(8,2) Not null,
Exc_type Varchar(50) Not Null,
ManagerID	Int	not null FOREIGN KEY REFERENCES Manager(ManagerID),
TrainerId int not null foreign key references Trainer(TrainerId)
);

insert into customers(Customer_name,Cust_join_date, Cust_height, Cust_weight, Cust_package_name, Exc_type, Cust_pay_amount, ManagerID, TrainerId)
values  ('Rahim','2020-01-01','1.69m','59kg','pack','Abs',12000.00,1,3003),
		('Jack','2021-02-23','1.732m','60kg','pack','Back',15000.00,1,3004),
		('Alex','2022-03-07','1.701m','66kg','pack','Arms',16000.00,2,3002),
		('Arafah','2020-04-11','1.794m','71kg','pack','Chest',15500.00,3,3004),
		('Yasir','2022-05-21','1.733m','73kg','pack','Abs',12900.00,2,3003),
		('Riya','2019-09-05','1.68m','63kg','pack','Chest',10000.00,2,3000),
		('Mira','2021-02-01','1.701m','65kg','pack','Arms',14000.00,3,3003);



create table  Equipments(
Equip_name	Varchar(50)	Not Null,
Equip_buy_date	Date Not Null,
Equip_maintenance varchar(50) Not Null,
Equip_payment_ID	Int	Not Null,
Equip_cost	Numeric(8,2)	Not Null
);

insert into Equipments(Equip_name, equip_buy_date, Equip_maintenance, Equip_payment_ID, Equip_cost)
values ('Power rack','2019-01-01', '6 months', 23414, 40000.00),
		('Chest press machine','2019-01-01', '4 months', 23451, 18000.00),
		('Lat pulldown machine ','2020-01-01', '2 months', 26432, 34000.00),
		('Roman chair','2019-03-01', '3 months', 47839, 39000.00),
		('Hammer strength machine','2019-01-01', '3 months', 74199, 27000.00),
		('Adjustable weight bench','2019-01-01', '3 months', 74212, 16000.00);

create table Membership(
MemberID	Int	identity(2000,1) not null primary key,
Date_created	Date	Not Null,
Expiry_dates	Date	Not Null,
Trainer Int not null FOREIGN KEY REFERENCES  Trainer(TrainerId),
CustomerID	Int not null FOREIGN KEY REFERENCES Customers(CustomerID)
);
insert into Membership(Date_created, Expiry_dates, Trainer, CustomerID)
values  ('2020-01-01','2025-01-01',3000,1000),
		('2020-04-11','2024-04-11',3001,1003),
		('2021-02-23','2024-02-23',3001,1001),
		('2022-03-07','2025-03-07',3002,1002),
		('2022-05-21','2025-05-21',3000,1004),
		('2019-09-05','2023-09-05',3004,1005),
		('2021-02-01','2024-02-01',3004,1006);
create Table  Package (
Pack_name	Varchar(50)	Not Null,
Pack_duration Date Not Null,
Pack_price	Numeric(8,2)	Not Null,
Pack_Rate_Cust varchar(50) null,
CustomerID	Int not null FOREIGN KEY REFERENCES Customers(CustomerID)
);

insert into Package(Pack_name, Pack_duration, Pack_price, Pack_Rate_Cust, CustomerID)
values	('Gold','2021-12-01', 25000.00, '5 star',1000),
		('Gold','2022-02-23', 25000.00, '4 star',1001),
		('Premiere','2022-09-07', 30000.00,'5 star', 1002),
		('Elite','2022-04-11', 20000.00, '',1003),
		('Basic','2024-05-21',18000.00,'3 star',1004),
		('Premiere','2020-09-05',30000.00,'3 star',1005),
		('Basic','2021-12-01',17000.00,'4 star',1006);

create table login(
UserName varchar(40),
Password varchar(20)
)
Insert into login (UserName,Password)
values('ADMIN' , '123456');
select *from login




select * from Manager;
select * from Customers;
select * from Trainer;
select * from Equipments;
select * from Membership;
select * from Package;
select * from Staff;